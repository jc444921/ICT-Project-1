<?php
session_start();
include_once('include/config.php');
?>

<!DOCTYPE HTML>
<!--
	TXT by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>WeCare Massage and Theraphy</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body class="homepage">
		<div id="page-wrapper">
			<?php include("include/nav.inc")?>
            
    <script src="assets/js/show_text.js"></script>
            
<!-- Slideshow container -->
<div class="slideshow-container" style="max-width:1700px;">

  <!-- Full-width images with number and caption text -->
  <div class="mySlides fade">
    <div class="numbertext">1 / 3</div>
    <img src="images/slideshow img 1.jpg">
    <div class="text">Caption Text</div>
  </div>

  <div class="mySlides fade">
    <div class="numbertext">2 / 3</div>
    <img src="images/slideshow img 1.jpg">
    <div class="text">Caption Two</div>
  </div>

  <div class="mySlides fade">
    <div class="numbertext">3 / 3</div>
    <img src="images/slideshow img 1.jpg">
    <div class="text">Caption Three</div>
  </div>

  <!-- Next and previous buttons -->
  <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
  <a class="next" onclick="plusSlides(1)" >&#10095;</a>
</div>
<br>

<!-- The dots/circles -->
<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 
</div>
			<!-- Main -->
				<div id="main-wrapper">
					<div id="main" class="container">
						<div class="row 200%">
							<div class="12u">

								<!-- Highlight -->
									<section class="box highlight">
										
										<header>
											<h2>JOIN OUR WECARE FAMILY </h2>
											
										</header>
										<p>
											
										</p>
									</section>

							</div>
						</div>
						<div class="row 200%">
							<div class="12u">

								<!-- Features -->
									<section class="box features">
										<h2 class="major"><span>CAREERS</span></h2>
										<div>
											<div class="row">
												<div class="3u 12u(mobile)">

													<!-- Feature -->
														<section class="box feature">
															
															<h2><a href="#">Senior Massage Theraphist</a></h2>
                                                            
															<p>
																<b>About the role</b>

An energetic person to perform quality massage targeting the clients at WeCare. A sound knowledge of Remedial and sports massage is essential.Looking for a therapist who can work with full time.

<p><b>Benefits and perks</b><span style="display:none;" id="expand-text">Flexible working environment. All equipment is provided. .</span> <a id="expand-click" href="javacript:;" style="text-decoration:none;" onClick="show_text('expand-click','expand-text','inline')"> Read more</a>
       </p>

  </p>
  

												  </section>

												</div>
												<div class="3u 12u(mobile)">

													<!-- Feature -->
														<section class="box feature">
														
															<h2><a href="#">Remedial Massage Therapist</a></h2>
                                                            
															
																											<p>
																<b>About the role</b>

An energetic person to perform quality massage targeting the clients at WeCare. A sound knowledge of Remedial and sports massage is essential.Looking for a therapist who can work with full time.

<p><b>Benefits and perks</b><span style="display:none;" id="expand-text4">Flexible working environment. All equipment is provided. .</span> <a id="expand-click4" href="javacript:;" style="text-decoration:none;" onClick="show_text('expand-click4','expand-text4','inline')"> Read more</a>
       </p>

  </p>
												  </section>

												</div>
											  <div class="3u 12u(mobile)">

													<!-- Feature -->
														<section class="box feature">
															
															<h2><a href="#">Spa Therapist</a></h2>
                                                            <p></p>                                                           
																<p>
																<b>About the role</b>

An energetic person to perform quality massage targeting the clients at WeCare. A sound knowledge of Remedial and sports massage is essential.Looking for a therapist who can work with full time.

<p><b>Benefits and perks</b><span style="display:none;" id="expand-text2">Flexible working environment. All equipment is provided. .</span> <a id="expand-click2" href="javacript:;" style="text-decoration:none;" onClick="show_text('expand-click2','expand-text2','inline')"> Read more</a>
       </p>

  </p>

									
												  </section>

												</div>
											  <div class="3u 12u(mobile)">

													<!-- Feature -->
														<section class="box feature">
															
															<h2><a href="#">Sport Massage Professional</a></h2>
                                                            
																											<p>
																<b>About the role</b>

An energetic person to perform quality massage targeting the clients at WeCare. A sound knowledge of Remedial and sports massage is essential.Looking for a therapist who can work with full time.

<p><b>Benefits and perks</b><span style="display:none;" id="expand-text5">Flexible working environment. All equipment is provided. .</span> <a id="expand-click5	" href="javacript:;" style="text-decoration:none;" onClick="show_text('expand-click5','expand-text5','inline')"> Read more</a>
       </p>


</p>
									
       
												</section>
                                                
                         
								
								<!-- Blog --><div

												</div>
                                                
                                                <div class="row 200%">
							<div class="12u">

									<section class="box blog">
									
										<div>
											<div class="row">
												<div class="9u 12u(mobile)">
													<div class="content content-left">

														<!-- Featured Post -->
															

													</div>
												</div>
											</div>
										</div>
									</section>

							</div>
                            
                            
						</div>
					</div>
				</div>

			<!-- Footer -->
				<footer id="footer" class="container">
					<div class="row 200%">
						<div class="12u">

							<!-- About -->
								
						</div>
					</div>
					<div class="row 200%">
						<div class="12u">
                       <h1 align="center" > Email Us Your Resumes On : wecare@gmail.com</h1>	
  
  <h1 align="center" > We value energetic proffessionals with a passion for remedial treatment industry. We look forward to welcoming you on board our family.</h1>	
  <br>
							<!-- Contact -->
								<section>
									<h2 class="major"><span>Get in touch</span></h2>
									<ul class="contact">
                                    
                                    
										<li><a class="icon fa-facebook" href="https://www.facebook.com/wecaremassage"><span class="label">Facebook</span></a></li>
										<li><a class="icon fa-twitter" href="#"><span class="label">Twitter</span></a></li>
										<li><a class="icon fa-instagram" href="#"><span class="label">Instagram</span></a></li>
										<li><a class="icon fa-dribbble" href="#"><span class="label">Dribbble</span></a></li>
										<li><a class="icon fa-google-plus" href="#"><span class="label">Google+</span></a></li>
									</ul>
								</section>

						</div>
					</div>

					<!-- Copyright -->
						<div id="copyright">
							<ul class="menu">
								<li>&copy; WeCare Massage. All rights reserved</li>
							</ul>
						</div>

				</footer>

	</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
	<script src="assets/js/jquery.dropotron.min.js"></script>
	<script src="assets/js/skel.min.js"></script>
	<script src="assets/js/skel-viewport.min.js"></script>
	<script src="assets/js/util.js"></script>
          
            
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
	<script src="assets/js/main.js"></script>
          </div>
	</body>
</html>