<?php
session_start();
include_once('include/config.php');
?>

<!DOCTYPE HTML>
<!--
	WeCare Massage and Theraphy
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>WeCare Massage and Theraphy</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body class="homepage">
		<div id="page-wrapper">
		<?php include("include/nav.inc")?>
			

			<!-- Banner -->
				<!-- <div id="banner-wrapper" style="background-image:url(images/background_image.jpg)" >
					<section id="banner">
						<h2>WELCOME TO WECARE MASSAGE & NATURAL THERAPHY</h2>
						<a href="#" class="button">Alright let's go</a>
					</section>
				</div> -->
<!-- Slideshow container -->
<div class="slideshow-container" style="max-width:1700px;">

  <!-- Full-width images with number and caption text -->
   <div class="mySlides fade">
    <div class="numbertext">1 / 3</div>
    <img src="images/slideshow img 1.jpg">
    <div class="text">Theraphuetic Massage</div>
  </div>

  <div class="mySlides fade">
    <div class="numbertext">2 / 3</div>	
    <img src="images/backgroundimage2.jpg">
    <div class="text">Remedial Massage</div>
  </div>

  <div class="mySlides fade">
    <div class="numbertext">3 / 3</div>
    <img src="images/backgroundimage3.jpg">
    <div class="text">Oil Massage</div>
  </div>

  <!-- Next and previous buttons -->
  <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
  <a class="next" onclick="plusSlides(1)" >&#10095;</a>
</div>
<br>

<!-- The dots/circles -->
<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 
</div>
			<!-- Main -->
				<div id="main-wrapper">
					<div id="main" class="container">
						<div class="row 200%">
							<div class="12u">

								<!-- Highlight -->
									<section class="box highlight">
										<ul class="special">
											
										</ul>
										<header>
											
											
										</header>
										<p>
										<h2><b>CONTACT US ON </b></h2>
											<p><b>Tel:</b> 07 3511 1550 </p>
                                            <a href=":https://www.facebook.com/wecaremassage"> Facebook: www.facebook.com/wecaremassage</a>
                                            <p>WeCARE Massage & Natural Therapy</p>

											<p></p>Shop 8/974 Waterworks Road, The Gap

											<br>Street side of The Gap Village Shopping Center

											<br>Between Pizza Capers and The Lodge Coffee

											<p>Brisbane, Queensland, Australia</p>
                                            
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d56621.6159180479!2d152.97503350007412!3d-27.505009135848912!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6b9156cdadcf48b7%3A0x72f7b1801d279b83!2sWeCARE+Massage+%26+Natural+Therapy!5e0!3m2!1sen!2sau!4v1517023868763" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
										</p>
									</section>

							</div>
						</div>
						<div class="row 200%">
							<div class="12u">

								
							</div>
						</div>
						<div class="row 200%">
							<div class="12u">

								

							</div>
						</div>
					</div>
				</div>

			<!-- Footer -->
				<footer id="footer" class="container">
					<div class="row 200%">
						<div class="12u">

							<!-- About -->
								<section>
									
								</section>

						</div>
					</div>
					<div class="row 200%">
						<div class="12u">

							<!-- Contact -->
								<section>
									<h2 class="major"><span>Get in touch</span></h2>
									<ul class="contact">
										<li><a class="icon fa-facebook" href="https://www.facebook.com/wecaremassage"><span class="label">Facebook</span></a></li>
										<li><a class="icon fa-twitter" href="#"><span class="label">Twitter</span></a></li>
										<li><a class="icon fa-instagram" href="#"><span class="label">Instagram</span></a></li>
										<li><a class="icon fa-dribbble" href="#"><span class="label">Dribbble</span></a></li>
										<li><a class="icon fa-google-plus" href="#"><span class="label">Google+</span></a></li>
									</ul>
								</section>

						</div>
					</div>

					<!-- Copyright -->
						<div id="copyright">
							<ul class="menu">
								<li>&copy; WeCare Massage. All rights reserved</li>
							</ul>
						</div>

				</footer>

	</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/skel-viewport.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>