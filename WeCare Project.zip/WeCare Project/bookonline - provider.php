<?php
session_start();
include_once('include/config.php');
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>WeCare Massage and Theraphy</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="homepage">
		<div id="page-wrapper">
		<?php include("include/nav.inc")?>
		

			<!-- Main -->
				<div id="main-wrapper">
					<div id="main" class="container">
						<div class="row 200%"> </div>
						<div class="row 200%">
							<div class="12u">
<!--FORM FOR BOOKING ONLINE-->
<link rel="stylesheet" href="assets/css/BOOKONLINE.CSS" />

<form novalidate class="simple_form new_online_booking_form" id="new_online_booking_form" action="/online_bookings" accept-charset="UTF-8" method="post">
	<input name="utf8" type="hidden" value="&#x2713;" />
    <input type="hidden" name="authenticity_token" value="4GLvFG7QxFGzPMap6906cNuTWXKRQP8zBl8gZsMbC9NjfBwkxQ3uuP/8kcTaEMdO2RJLtOiQEhwsEFg+UK5WQg==" />
<div class='top-bar'>
	<input type="hidden" name="previous_step" id="previous_step" value="employee" />
	<input type="submit" name="commit" value="" class="hide-but-display" tabindex="-1" />
<div class='back'>
<!-- Generator: Adobe Illustrator 17.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<svg version="1.1"
	 xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 48 48" enable-background="new 0 0 48 48" xml:space="preserve">
<switch>
	<g>
		<g id="Layer_1">
		</g>
		<g id="right-rotate">
		</g>
		<g id="left-rotate">
		</g>
		<g id="share-down">
		</g>
		<g id="share-top">
		</g>
		<g id="share-both">
		</g>
		<g id="share-top-right">
		</g>
		<g id="share-top-left">
		</g>
		<g id="share-right-down">
		</g>
		<g id="share-left-down">
		</g>
		<g id="recycle-arw">
		</g>
		<g id="verticle-hidden-arw">
		</g>
		<g id="horizontal-arw">
		</g>
		<g id="verticle-arw">
		</g>
		<g id="connection-arw-r">
		</g>
		<g id="connection-arw-l">
		</g>
		<g id="connection-arw">
		</g>
		<g id="hook-left-arw">
		</g>
		<g id="clock-arw">
		</g>
		<g id="anti-clock-arw">
		</g>
		<g id="infinity">
		</g>
		<g id="sing-sang-arw">
		</g>
		<g id="anti-reload">
		</g>
		<g id="reload">
		</g>
		<g id="double-arrow">
		</g>
		<g id="single-circle-arw">
		</g>
		<g id="circle-arw">
		</g>
		<g id="two-side-bend-arw">
		</g>
		<g id="left-blend-arw">
		</g>
		<g id="right-blend-arw">
		</g>
		<g id="round-extand">
		</g>
		<g id="round-close-arrow">
		</g>
		<g id="pluse-arrow">
		</g>
		<g id="crose-arrow">
		</g>
		<g id="corn-arrow">
		</g>
		<g id="side-arrow">
		</g>
		<g id="close-arrow-four">
		</g>
		<g id="stretch-arrow">
		</g>
		<g id="_x33__x2F_1-arrow">
		</g>
		<g id="_x32__x2F_1-arrow">
		</g>
		<g id="left-crose-rd">
		</g>
		<g id="left-crose-arrow">
		</g>
		<g id="left-top_arrows">
		</g>
		<g id="close-arrows">
		</g>
		<g id="extand-arrow">
		</g>
		<g id="parallel-arrows">
		</g>
		<g id="two-side_arrows">
		</g>
		<g id="right-arrows">
		</g>
		<g id="down-arrow-3">
		</g>
		<g id="top-arrow-3">
		</g>
		<g id="right-arrow-3">
		</g>
		<g id="left-arrow-3">
		</g>
		<g id="left-arrow-2">
		</g>
		<g id="right-arrow-2">
		</g>
		<g id="down-arrow-2">
		</g>
		<g id="top-arrow-2">
		</g>
		<g id="down-arrow-1">
		</g>
		<g id="top-arrow-1">
		</g>
		<g id="rightarrow-1">
		</g>
		<g id="left-arrow-1">
		</g>
		<g id="down-play">
		</g>
		<g id="top-play">
		</g>
		<g id="right-play">
		</g>
		<g id="left-play">
		</g>
		<g id="down-arrow">
		</g>
		<g id="top-arrow">
		</g>
		<g id="right-arrow">
		</g>
		<g id="left-arrow">
		</g>
		<g id="channel">
		</g>
		<g id="stop_1_">
		</g>
		<g id="music-control">
		</g>
		<g id="adjust-lavel">
		</g>
		<g id="adjustsound">
		</g>
		<g id="graph-point">
		</g>
		<g id="symbol">
		</g>
		<g id="visual-graph">
		</g>
		<g id="visual">
		</g>
		<g id="adjust">
		</g>
		<g id="controal-4">
		</g>
		<g id="control-3">
		</g>
		<g id="control-2">
		</g>
		<g id="control_1_">
		</g>
		<g id="control">
		</g>
		<g id="volume-increase">
		</g>
		<g id="volume">
		</g>
		<g id="volume-close">
		</g>
		<g id="volume-minus">
		</g>
		<g id="volume-pluse">
		</g>
		<g id="block">
		</g>
		<g id="sound">
		</g>
		<g id="play-backward">
		</g>
		<g id="backward">
		</g>
		<g id="play">
		</g>
		<g id="hold">
		</g>
		<g id="stop">
		</g>
		<g id="pause">
		</g>
		<g id="forward">
		</g>
		<g id="play-forward">
		</g>
		<g id="top-bottom-arrow">
		</g>
		<g id="hook-right-arw">
		</g>
	</g>
</switch>
</svg>

</div>
<div class='title' style="margin-top:20px">Choose Provider</div>
</div>
<div id='error-presenter' style='display: none'>
<a class="close" href="#">✕</a>
</div>

<div class="form-group hidden online_booking_form_provider_id"><input class="hidden form-control" type="hidden" value="59886" name="online_booking_form[provider_id]" id="online_booking_form_provider_id" /></div>
<div class="form-group hidden online_booking_form_location_id"><input class="hidden form-control" type="hidden" value="" name="online_booking_form[location_id]" id="online_booking_form_location_id" /></div>
<div class="form-group hidden online_booking_form_source"><input class="hidden form-control" type="hidden" value="online_button" name="online_booking_form[source]" id="online_booking_form_source" /></div>
<input class="service-item-input-base" type="hidden" name="online_booking_form[service_pricing_level_ids][]" />
<div class='service-item-input-list'>
<input value="1456029" type="hidden" name="online_booking_form[service_pricing_level_ids][]" />
</div>
<div class="form-group hidden online_booking_form_employee_id"><input class="hidden form-control" type="hidden" value="" name="online_booking_form[employee_id]" id="online_booking_form_employee_id" /></div>
<div class="form-group hidden online_booking_form_date"><input class="hidden js-date form-control" type="hidden" value="2018-02-05" name="online_booking_form[date]" id="online_booking_form_date" /></div>
<div class="form-group hidden online_booking_form_time_start_in_seconds"><input class="hidden js-time-start-in-seconds form-control" type="hidden" value="" name="online_booking_form[time_start_in_seconds]" id="online_booking_form_time_start_in_seconds" /></div>
<input class="employee-assignment-input-base" type="hidden" name="online_booking_form[employee_assignment][]" />
<div class='employee-assignment-input-list'>
</div>
<input class="room-assignment-input-base" type="hidden" name="online_booking_form[room_assignment][]" />
<div class='room-assignment-input-list'>
</div>
<div class="form-group hidden online_booking_form_booking_id"><input class="hidden form-control" type="hidden" value="" name="online_booking_form[booking_id]" id="online_booking_form_booking_id" /></div>

<div class='scrollable'>
<div class='group-name'>Staff members</div>
<div class='group employee-group'>
<div aria-checked='false' class='item one-line without-checkbox' role='checkbox' tabindex='0'>
<div class='input-arrow'>
<input type="checkbox" name="online_booking_form[employee_id]" id="online_booking_form_employee_id" value="any" />
</div>
<div class='title'>
No Preference
</div>
</div>
<div aria-checked='false' class='item one-line without-checkbox' role='checkbox' tabindex='0'>
<div class='input-arrow'>
<input type="checkbox" name="online_booking_form[employee_id]" id="online_booking_form_employee_id" value="283642" />
</div>
<div class='title'>
Peter
</div>
</div>
<div aria-checked='false' class='item one-line without-checkbox' role='checkbox' tabindex='0'>
<div class='input-arrow'>
<input type="checkbox" name="online_booking_form[employee_id]" id="online_booking_form_employee_id" value="283641" />
</div>
<div class='title'>
DeeDee
</div>
</div>
<div aria-checked='false' class='item one-line without-checkbox' role='checkbox' tabindex='0'>
<div class='input-arrow'>
<input type="checkbox" name="online_booking_form[employee_id]" id="online_booking_form_employee_id" value="176617" />
</div>
<div class='title'>
Mak Yang
</div>
</div>
<div aria-checked='false' class='item one-line without-checkbox' role='checkbox' tabindex='0'>
<div class='input-arrow'>
<input type="checkbox" name="online_booking_form[employee_id]" id="online_booking_form_employee_id" value="176614" />
</div>
<div class='title'>
Xinyuan (Millie) Wang
</div>
</div>
<div aria-checked='false' class='item one-line without-checkbox' role='checkbox' tabindex='0'>
<div class='input-arrow'>
<input type="checkbox" name="online_booking_form[employee_id]" id="online_booking_form_employee_id" value="176616" />
</div>
<div class='title'>
Tiffany
</div>
</div>
<div aria-checked='false' class='item one-line without-checkbox' role='checkbox' tabindex='0'>
<div class='input-arrow'>
<input type="checkbox" name="online_booking_form[employee_id]" id="online_booking_form_employee_id" value="176770" />
</div>
<div class='title'>
Sharon
</div>
</div>
</div>
<input type="submit" name="commit" value="Next" class="hide" />
</div>
</form>

							
					</div>
				</div>

			<!-- Footer -->
				<footer id="footer" class="container">
					<div class="row 200%">
						<div class="12u">

							<!-- About -->
								<section>
									
								</section>

						</div>
					</div>
					<div class="row 200%">
						<div class="12u">

							<!-- Contact -->
								<section>
									<h2 class="major"><span>Get in touch</span></h2>
									<ul class="contact">
										<?php include("include/contact.inc")?>
									</ul>
								</section>

						</div>
					</div>

					<!-- Copyright -->
						<div id="copyright">
							<ul class="menu">
								<li>&copy; WeCare Massage. All rights reserved</li>
							</ul>
						</div>

				</footer>

	</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/skel-viewport.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>