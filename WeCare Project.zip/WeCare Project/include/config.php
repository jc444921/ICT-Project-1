<?php
//define constants for connection info
define("MYSQLUSER","jcubitgr_ict");
define("MYSQLPASS","123zxc");
define("HOSTNAME","box648.bluehost.com");
define("MYSQLDB","jcubitgr_wecare");

//make connection to database
function db_connect()
{
	$conn = @new mysquli(HOSTNAME, MYSQLUSER, MYSQLPASS, MYSQLDB);
	if ($conn -> connect_error){
		die('Connect Error: '.$conn -> connect_error);
	}
	return $conn;
}
?>
