<?php
session_start();
include_once('include/config.php');
?>

<!DOCTYPE HTML>
<!--
	WeCare Massage and Theraphy
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>WeCare Massage and Theraphy</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body class="homepage">
		<div id="page-wrapper">

			<?php include("include/nav.inc")?>

<!-- Slideshow container -->
<div class="slideshow-container" style="max-width:1700px;">

  <!-- Full-width images with number and caption text -->
  <div class="mySlides fade">
    <div class="numbertext">1 / 3</div>
    <img src="images/slideshow img 1.jpg">
    <div class="text">Caption Text</div>
  </div>

  <div class="mySlides fade">
    <div class="numbertext">2 / 3</div>
    <img src="images/slideshow img 1.jpg">
    <div class="text">Caption Two</div>
  </div>

  <div class="mySlides fade">
    <div class="numbertext">3 / 3</div>
    <img src="images/slideshow img 1.jpg">
    <div class="text">Caption Three</div>
  </div>

  <!-- Next and previous buttons -->
  <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
  <a class="next" onclick="plusSlides(1)" >&#10095;</a>
</div>
<br>

<!-- The dots/circles -->
<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 
</div>
			<!-- Main -->
				<div id="main-wrapper">
					<div id="main" class="container">
						<div class="row 200%">
							<div class="12u">

								<!-- Highlight -->
									<section class="box highlight">
										
										<header>
											<h2>OUR TREATMENTS </h2>
											
										</header>
										<p>
											
										</p>
									</section>

							</div>
						</div>
						<div class="row 200%">
							<div class="12u">

								<!-- Features -->
									<section class="box features">
										<h2 class="major"><span>PROFESSIONAL REMEDIAL TREATMENTS</span></h2>
										<div>
											<div class="row">
												<div class="3u 12u(mobile)">

													<!-- Feature -->
														<section class="box feature">
															<a href="#" class="image featured"><img src="file://///jcub.edu.au/homedirs$/jc412039/ICT_Project1/images/Headache_relief.png" alt="" /></a>
															<h3><a href="#">Headache Relief</a></h3>
                                                            <br>(Health Fund Rebate Available)
                                                            <p>20 mins- $30</p>
															<p>
																A combination of seated and lying down treatment for headache relief, tensions, migraine and insomnia relief.
															</p>
														</section>

												</div>
												<div class="3u 12u(mobile)">

													<!-- Feature -->
														<section class="box feature">
															<a href="#" class="image featured"><img src="images/Neck_Movement.png"alt="" style="width:270px;height:180px;"/></a>
															<h3><a href="#">Neck Movement Recovery</a></h3>
                                                            <br>(Health Fund Rebate Available)
                                                            <p>30 mins- $40</p>
															<p>
																A seated treatment for stiff neck and shoulder, torticollis, which can recover the range of neck movement and to relieve pains.
															</p>
														</section>

												</div>
												<div class="3u 12u(mobile)">

													<!-- Feature -->
														<section class="box feature">
															<a href="#" class="image featured"><img src="images/Scatia.png" alt="" style="width:270px;height:180px;" /></a>
															<h3><a href="#">Sciatica Nerve Treatment</a></h3>
                                                            <br>(Health Fund Rebate Available)
                                                            <p>40 mins- $50</p>
															<p>
																A lying down treatment for lower back, hip pains, pinched nerve and scatia. Irritation to the sciatic nerve causing pain and discomfort along one side of your lower to your legs/foot. It can be sharp or dull, constant or intermittent. It can result in sitting in one position for too long, muscle spasms, wearing high heels, obesity, slipped discs or bone spurs.
															</p>
														</section>

												</div>
											  <div class="3u 12u(mobile)">

													<!-- Feature -->
														<section class="box feature">
															<a href="#" class="image featured"><img src="images/Remidial_massage.png" alt="" style="width:270px;height:180px;"/></a>
															<h3><a href="#">Remedial Massage</a></h3>
                                                            <br>(Health Fund Rebate Available)
                                                            <p>60 mins- $70</p>
															<p>
																Remedial Massage provides a healing treatment that can be gentle, strong, deep or shallow.
                                                               Remedial massage holistically treats the whole body and traces the discomfort as far as possible back to the original cause, healing both the cause of the disorder as well as the symptoms. 
															</p>
       
												</section>

												</div>
											</div>
											<div class="row">
												<div class="12u">
													<ul class="actions">
														<li><a href="#" class="button big">Do Something</a></li>
														<li><a href="#" class="button alt big">Think About It</a></li>
													</ul>
												</div>
											</div>
										</div>
									</section>

							</div>
						</div>
						<div class="row 200%">
							<div class="12u">

								<!-- Blog -->
									<section class="box blog">
										<h2 class="major"><span>Another Major Heading</span></h2>
										<div>
											<div class="row">
												<div class="9u 12u(mobile)">
													<div class="content content-left">

														<!-- Featured Post -->
															<article class="box post">
																<header>
																	<h3><a href="#">Here's a really big heading</a></h3>
																	<p>With a smaller subtitle that attempts to elaborate</p>
																	<ul class="meta">
																		<li class="icon fa-clock-o">15 minutes ago</li>
																		<li class="icon fa-comments"><a href="#">8</a></li>
																	</ul>
																</header>
																<a href="#" class="image featured"><img src="images/pic05.jpg" alt="" /></a>
																<p>
																	Phasellus quam turpis, feugiat sit amet ornare in, a hendrerit in lectus. Praesent
																	semper mod quis eget mi. Etiam sed ante risus aliquam erat et volutpat. Praesent a
																	dapibus velit. Curabitur sed nisi nunc, accumsan vestibulum lectus. Lorem ipsum
																	dolor sit non aliquet sed, tempor et dolor.  Praesent a dapibus velit. Curabitur
																	accumsan.
																</p>
																<a href="#" class="button">Continue Reading</a>
															</article>

													</div>
												</div>
												<div class="3u 12u(mobile)">
													<div class="sidebar">

														<!-- Archives -->
															<ul class="divided">
																<li>
																	<article class="box post-summary">
																		<h3><a href="#">A Subheading</a></h3>
																		<ul class="meta">
																			<li class="icon fa-clock-o">6 hours ago</li>
																			<li class="icon fa-comments"><a href="#">34</a></li>
																		</ul>
																	</article>
																</li>
																<li>
																	<article class="box post-summary">
																		<h3><a href="#">Another Subheading</a></h3>
																		<ul class="meta">
																			<li class="icon fa-clock-o">9 hours ago</li>
																			<li class="icon fa-comments"><a href="#">27</a></li>
																		</ul>
																	</article>
																</li>
																<li>
																	<article class="box post-summary">
																		<h3><a href="#">And Another</a></h3>
																		<ul class="meta">
																			<li class="icon fa-clock-o">Yesterday</li>
																			<li class="icon fa-comments"><a href="#">184</a></li>
																		</ul>
																	</article>
																</li>
																<li>
																	<article class="box post-summary">
																		<h3><a href="#">And Another</a></h3>
																		<ul class="meta">
																			<li class="icon fa-clock-o">2 days ago</li>
																			<li class="icon fa-comments"><a href="#">286</a></li>
																		</ul>
																	</article>
																</li>
																<li>
																	<article class="box post-summary">
																		<h3><a href="#">And One More</a></h3>
																		<ul class="meta">
																			<li class="icon fa-clock-o">3 days ago</li>
																			<li class="icon fa-comments"><a href="#">8,086</a></li>
																		</ul>
																	</article>
																</li>
															</ul>
															<a href="#" class="button alt">Browse Archives</a>

													</div>
												</div>
											</div>
										</div>
									</section>

							</div>
						</div>
					</div>
				</div>

			<!-- Footer -->
				<footer id="footer" class="container">
					<div class="row 200%">
						<div class="12u">

							<!-- About -->
								<section>
									
								</section>

						</div>
					</div>
					<div class="row 200%">
						<div class="12u">

							<!-- Contact -->
								<section>
									<h2 class="major"><span>Get in touch</span></h2>
									<ul class="contact">
										<li><a class="icon fa-facebook" href="#"><span class="label">Facebook</span></a></li>
										<li><a class="icon fa-twitter" href="#"><span class="label">Twitter</span></a></li>
										<li><a class="icon fa-instagram" href="#"><span class="label">Instagram</span></a></li>
										<li><a class="icon fa-dribbble" href="#"><span class="label">Dribbble</span></a></li>
										<li><a class="icon fa-google-plus" href="#"><span class="label">Google+</span></a></li>
									</ul>
								</section>

						</div>
					</div>

					<!-- Copyright -->
						<div id="copyright">
							<ul class="menu">
								<li>&copy; WeCare Massage. All rights reserved</li>
							</ul>
						</div>

				</footer>

	</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/skel-viewport.min.js"></script>
			<script src="assets/js/util.js"></script>
            
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>
            <script src="js/show_text.js"></script>

	</body>
</html>