<?php
session_start();
include_once('include/config.php');
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>WeCare Massage and Theraphy</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="homepage">
		<div id="page-wrapper">
		<?php include("include/nav.inc")?>
		

			<!-- Main -->
				<div id="main-wrapper">
					<div id="main" class="container">
						<div class="row 200%"> </div>
						<div class="row 200%">
							<div class="12u">
<!--FORM FOR BOOKING ONLINE-->
<link rel="stylesheet" href="assets/css/BOOKONLINE.CSS" />

<form novalidate="novalidate" class="simple_form new_online_booking_form" id="new_online_booking_form" 
		action="/online_bookings" accept-charset="UTF-8" method="post">
<input name="utf8" type="hidden" value="&#x2713;" />
<input type="hidden" name="authenticity_token" value="TrzPU42MW2TywPKtO6dHaEJ+R/iqMyZ7ZLR+vLy7Zn3NojxjJlFxjb4ApcAKarpWQP9VPtPjy1RO+wbkLw477A==" />

<div class='top-bar'>
<input type="hidden" name="previous_step" id="previous_step" value="services" />
<div class='title' style="margin-top:20px">Book Services</div>
</div>
<div id='error-presenter' style='display: none'>
<a class="close" href="#">✕</a>
</div>

<div class="form-group hidden online_booking_form_provider_id"><input class="hidden form-control" type="hidden" value="59886" name="online_booking_form[provider_id]" id="online_booking_form_provider_id" /></div>
<div class="form-group hidden online_booking_form_location_id"><input class="hidden form-control" type="hidden" name="online_booking_form[location_id]" id="online_booking_form_location_id" /></div>
<div class="form-group hidden online_booking_form_source"><input class="hidden form-control" type="hidden" value="online_button" name="online_booking_form[source]" id="online_booking_form_source" /></div>
<input class="service-item-input-base" type="hidden" name="online_booking_form[service_pricing_level_ids][]" />
<div class='service-item-input-list'>
</div>
<div class="form-group hidden online_booking_form_employee_id"><input class="hidden form-control" type="hidden" name="online_booking_form[employee_id]" id="online_booking_form_employee_id" /></div>
<div class="form-group hidden online_booking_form_date"><input class="hidden js-date form-control" type="hidden" value="2018-02-05" name="online_booking_form[date]" id="online_booking_form_date" /></div>
<div class="form-group hidden online_booking_form_time_start_in_seconds"><input class="hidden js-time-start-in-seconds form-control" type="hidden" name="online_booking_form[time_start_in_seconds]" id="online_booking_form_time_start_in_seconds" /></div>
<input class="employee-assignment-input-base" type="hidden" name="online_booking_form[employee_assignment][]" />
<div class='employee-assignment-input-list'>
</div>
<input class="room-assignment-input-base" type="hidden" name="online_booking_form[room_assignment][]" />
<div class='room-assignment-input-list'>
</div>
<div class="form-group hidden online_booking_form_booking_id"><input class="hidden form-control" type="hidden" name="online_booking_form[booking_id]" id="online_booking_form_booking_id" /></div>

<div class='scrollable'>
<div class='group-name'>massage</div>
<div class='group service-pricing-level-group'>
<div aria-checked='false' class='item' role='checkbox' tabindex='0'>
<div class='input'>
<input type="checkbox" id="" value="1456029" />
</div>
<div class='right'>
<div class='js-price text-right' data-price='35.0'>$35</div>
</div>
<div class='title'>
massage
</div>
<div class='subtitle'>
30min
</div>
</div>
<div aria-checked='false' class='item' role='checkbox' tabindex='0'>
<div class='input'>
<input type="checkbox" id="" value="1456028" />
</div>
<div class='right'>
<div class='js-price text-right' data-price='15.0'>$15</div>
</div>
<div class='title'>
Neck
</div>
<div class='subtitle'>
10min
</div>
</div>
<div aria-checked='false' class='item' role='checkbox' tabindex='0'>
<div class='input'>
<input type="checkbox" id="" value="893251" />
</div>
<div class='right'>
<div class='js-price text-right' data-price='110.0'>$110</div>
</div>
<div class='title'>
Remedial Massage+Reflexology(100mins)
</div>
<div class='subtitle'>
1h 40min
</div>
</div>
<div aria-checked='false' class='item' role='checkbox' tabindex='0'>
<div class='input'>
<input type="checkbox" id="" value="893249" />
</div>
<div class='right'>
<div class='js-price text-right' data-price='100.0'>$100</div>
</div>
<div class='title'>
Remedial Massage(1.5 hour)
</div>
<div class='subtitle'>
1h 30min
</div>
</div>
<div aria-checked='false' class='item' role='checkbox' tabindex='0'>
<div class='input'>
<input type="checkbox" id="" value="893248" />
</div>
<div class='right'>
<div class='js-price text-right' data-price='50.0'>$50</div>
</div>
<div class='title'>
Remedial Massage(Lower Back&amp;Hips)
</div>
<div class='subtitle'>
40min
</div>
</div>
<div aria-checked='false' class='item' role='checkbox' tabindex='0'>
<div class='input'>
<input type="checkbox" id="" value="892329" />
</div>
<div class='right'>
<div class='js-price text-right' data-price='30.0'>$30</div>
</div>
<div class='title'>
Remedial Massage(Neck&amp;Shoulder)
</div>
<div class='subtitle'>
20min
</div>
</div>
<div aria-checked='false' class='item' role='checkbox' tabindex='0'>
<div class='input'>
<input type="checkbox" id="" value="892149" />
</div>
<div class='right'>
<div class='js-price text-right' data-price='40.0'>$40</div>
</div>
<div class='title'>
Remedial Massage(Neck&amp;Shoulder)
</div>
<div class='subtitle'>
30min
</div>
</div>
<div aria-checked='false' class='item' role='checkbox' tabindex='0'>
<div class='input'>
<input type="checkbox" id="" value="892148" />
</div>
<div class='right'>
<div class='js-price text-right' data-price='50.0'>$50</div>
</div>
<div class='title'>
Remedial Massage(Neck Shoulder&amp;Back)
</div>
<div class='subtitle'>
40min
</div>
</div>
<div aria-checked='false' class='item' role='checkbox' tabindex='0'>
<div class='input'>
<input type="checkbox" id="" value="892147" />
</div>
<div class='right'>
<div class='js-price text-right' data-price='55.0'>$55</div>
</div>
<div class='title'>
Remedial Massage(Back)
</div>
<div class='subtitle'>
45min
</div>
</div>
<div aria-checked='false' class='item' role='checkbox' tabindex='0'>
<div class='input'>
<input type="checkbox" id="" value="892146" />
</div>
<div class='right'>
<div class='js-price text-right' data-price='70.0'>$70</div>
</div>
<div class='title'>
Remedial Massage(1 hour)
</div>
<div class='subtitle'>
1h
</div>
</div>
</div>
</div>
<div>
<div class='regular summary'>
<div class='selection-summary'>
<div class='text normal'>
You have selected
</div>
<div class='text at-limit'>
Maximum selected
</div>
<span class='services-total-count'>0</span>
<span class='services-total-items-text'>item(s),</span>
<span class='services-total-price'>-</span>

<div class='actions'>
<input type="submit" name="commit" value="Book now" />
</div>
</div>
<div class='floating summary'>
<div class='selection-summary'>
<div class='text normal'>
You have selected
</div>
<div class='text at-limit'>
Maximum selected
</div>
<span class='services-total-count'>0</span>
<span class='services-total-items-text'>item(s),</span>
<span class='services-total-price'>-</span>
</div>
<div class='actions' style="margin-top:1200px">
<input type="submit" name="commit" value="Book now" />
</div></div>
</div>
</div>
</form>
</div>
</div>
							
					</div>
				</div>

			<!-- Footer -->
				<footer id="footer" class="container">
					<div class="row 200%">
						<div class="12u">

							<!-- About -->
								<section>
									
								</section>

						</div>
					</div>
					<div class="row 200%">
						<div class="12u">

							<!-- Contact -->
								<section>
									<h2 class="major"><span>Get in touch</span></h2>
									<ul class="contact">
										<li><a class="icon fa-facebook" href="https://www.facebook.com/wecaremassage"><span class="label">Facebook</span></a></li>
										<li><a class="icon fa-twitter" href="#"><span class="label">Twitter</span></a></li>
										<li><a class="icon fa-instagram" href="#"><span class="label">Instagram</span></a></li>
										<li><a class="icon fa-dribbble" href="#"><span class="label">Dribbble</span></a></li>
										<li><a class="icon fa-google-plus" href="#"><span class="label">Google+</span></a></li>
									</ul>
								</section>

						</div>
					</div>

					<!-- Copyright -->
						<div id="copyright">
							<ul class="menu">
								<li>&copy; WeCare Massage. All rights reserved</li>
							</ul>
						</div>

				</footer>

	</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/skel-viewport.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>