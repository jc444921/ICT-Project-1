<?php
session_start();
include_once('include/config.php');
?>

<!DOCTYPE HTML>
<!--
	TXT by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>WeCare Massage and Theraphy</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body class="homepage">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header">
					<div class="logo container">
						<div>
							<h1><a href="index.html" id="logo"/a></h1>
							<p>WeCare Massage & Natural Theraphy</p>
						</div>
					</div>
				</header>

			<?php include("include/nav.inc")?>

<!-- Slideshow container -->
<div class="slideshow-container" style="max-width:1700px;">

  <!-- Full-width images with number and caption text -->
  <div class="mySlides fade">
    <div class="numbertext">1 / 3</div>
    <img src="images/slideshow img 1.jpg">
    <div class="text">Theraphuetic Massage</div>
  </div>

  <div class="mySlides fade">
    <div class="numbertext">2 / 3</div>	
    <img src="images/backgroundimage2.jpg">
    <div class="text">Remedial Massage</div>
  </div>

  <div class="mySlides fade">
    <div class="numbertext">3 / 3</div>
    <img src="images/backgroundimage3.jpg">
    <div class="text">Oil Massage</div>
  </div>

  <!-- Next and previous buttons -->
  <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
  <a class="next" onclick="plusSlides(1)" >&#10095;</a>
</div>
<br>

<!-- The dots/circles -->
<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 
</div>
			<!-- Main -->
				<div id="main-wrapper">
					<div id="main" class="container">
						<div class="row 200%">
							<div class="12u">

								<!-- Highlight -->
									<section class="box highlight">
										
										<header>
											<h2>PRODUCTS </h2>
											
										</header>
										<p>
											
										</p>
									</section>

							</div>
						</div>
						<div class="row 200%">
							<div class="12u">

								<!-- Features -->
									<section class="box features">
										<h2 class="major"><span>PRODUCTS RANGE</span></h2>
                                        <h3 align="center">Steam Eye Mask $2 for each </h3>
                                                                                <p align="center" >We would like to introduce our Steam Eye Mask to all our valuable customers. Comfortable heat (40℃) generated from Steam Eye Mask gradually spreads to gently envelop your eyes. Particularly helpful for headache and sore eyes. There are five range of Eye Mask, which are unscented, lavender, chamomile-ginger, rose and grapefruit. You can have our Eye Mask for free of Reflexology-related services.!</p>
                                                                                
                                                                                        <p align="center" >The combination of Eye Mask and Massage is perfect. Enjoy the de-stressing session. Refresh yourself with brighter looking eyes!</p>
	<div>
											<div class="row">
												<div class="3u 12u(mobile)">

													<!-- Feature -->
														<section class="box feature">
															<a href="#" class="image featured"><img src="images/Mask1.jpg" alt=""  style="width:270px;height:130px;" /></a>
															<h3><a href="#">Unscented</a></h3>
                                                            
															<p>
																
															</p>
														</section>

												</div>
												<div class="3u 12u(mobile)">

													<!-- Feature -->
														<section class="box feature">
														  <a href="#" class="image featured"><img src="images/Mask2.jpg" alt=""  style="width:270px;height:130px;" /></a>
															<h3><a href="#">Chamomile-ginger aroma</a></h3>
                                                           
														</section>

												</div>
												<div class="3u 12u(mobile)">

													<!-- Feature -->
														<section class="box feature">
															<a href="#" class="image featured"><img src="images/Mask3.jpg" alt=""  style="width:270px;height:130px;" /></a>
															<h3><a href="#">Lavender - Sage Aroma</a></h3>
                                                           
															
															</p>
														</section>

												</div>
											  <div class="3u 12u(mobile)">

													<!-- Feature -->
														<section class="box feature">
															<a href="#" class="image featured"><img src="images/Mask4.jpg" alt=""  style="width:270px;height:130px;" /></a>
															<h3><a href="#">Fresh Rose Aroma</a></h3>
                                                            
															
       
												</section>

												</div>
                                                
                                                <div class="row 200%">
							<div class="12u">

								<!-- Features -->
									<section class="box features">
										
										<div>
											<div class="row">
												<div class="3u 12u(mobile)">

													

													

												</div>

								<!-- Blog -->
									
							</div>
                            
                            
						
                        
	</div>
			
	<!-- Footer -->
				<footer id="footer" class="container">
					<div class="row 200%">
						<div class="12u">

							<!-- About -->
								<section>
									
								</section>

						</div>
					</div>
					<div class="row 200%">
						<div class="12u">

							<!-- Contact -->
								<section>
									<h2 class="major"><span>Get in touch</span></h2>
									<ul class="contact">
										<li><a class="icon fa-facebook" href="https://www.facebook.com/wecaremassage"><span class="label">Facebook</span></a></li>
										<li><a class="icon fa-twitter" href="#"><span class="label">Twitter</span></a></li>
										<li><a class="icon fa-instagram" href="#"><span class="label">Instagram</span></a></li>
										<li><a class="icon fa-dribbble" href="#"><span class="label">Dribbble</span></a></li>
										<li><a class="icon fa-google-plus" href="#"><span class="label">Google+</span></a></li>
									</ul>
								</section>

						</div>
					</div>

					<!-- Copyright -->
						<div id="copyright">
							<ul class="menu">
								<li>&copy; WeCare Massage. All rights reserved</li>
							</ul>
						</div>

				</footer>

	</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/skel-viewport.min.js"></script>
			<script src="assets/js/util.js"></script>
            
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>
            <script src="js/show_text.js"></script>

	</body>
</html>