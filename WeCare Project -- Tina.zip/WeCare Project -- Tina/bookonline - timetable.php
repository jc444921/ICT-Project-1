<?php
session_start();
include_once('include/config.php');
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>WeCare Massage and Theraphy</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="homepage">
		<div id="page-wrapper">
		<?php include("include/nav.inc")?>
		

			<!-- Main -->
				<div id="main-wrapper">
					<div id="main" class="container">
						<div class="row 200%"> </div>
						<div class="row 200%">
							<div class="12u">
                            
<!--FORM FOR BOOKING ONLINE-->
<link rel="stylesheet" href="assets/css/BOOKONLINE.CSS" />

<div id="online-booking-time-slot-form">
<form novalidate="novalidate" class="simple_form new_online_booking_form" id="new_online_booking_form" action="/online_bookings" accept-charset="UTF-8" method="post"><input name="utf8" type="hidden" value="✓"><input type="hidden" name="authenticity_token" value="t38+c1KthIILWVFyTkI1utrp/YdgHx8dOr/8v5tPiDE0Yc1D+XCua0eZBh9/j8iE2GjvQRnP8jIQ8ITnCPrVoA=="><div class="top-bar">
<input type="hidden" name="previous_step" id="previous_step" value="time_slot">
<input type="submit" name="commit" value="" class="hide-but-display" tabindex="-1">
<div class="back">
<input type="submit" name="back" value="">
<!--?xml version="1.0" encoding="utf-8"?-->
<!-- Generator: Adobe Illustrator 17.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->

<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 48 48" enable-background="new 0 0 48 48" xml:space="preserve">
<switch>
	<g>
		<g id="Layer_1">
		</g>
		<g id="right-rotate">
		</g>
		<g id="left-rotate">
		</g>
		<g id="share-down">
		</g>
		<g id="share-top">
		</g>
		<g id="share-both">
		</g>
		<g id="share-top-right">
		</g>
		<g id="share-top-left">
		</g>
		<g id="share-right-down">
		</g>
		<g id="share-left-down">
		</g>
		<g id="recycle-arw">
		</g>
		<g id="verticle-hidden-arw">
		</g>
		<g id="horizontal-arw">
		</g>
		<g id="verticle-arw">
		</g>
		<g id="connection-arw-r">
		</g>
		<g id="connection-arw-l">
		</g>
		<g id="connection-arw">
		</g>
		<g id="hook-left-arw">
		</g>
		<g id="clock-arw">
		</g>
		<g id="anti-clock-arw">
		</g>
		<g id="infinity">
		</g>
		<g id="sing-sang-arw">
		</g>
		<g id="anti-reload">
		</g>
		<g id="reload">
		</g>
		<g id="double-arrow">
		</g>
		<g id="single-circle-arw">
		</g>
		<g id="circle-arw">
		</g>
		<g id="two-side-bend-arw">
		</g>
		<g id="left-blend-arw">
		</g>
		<g id="right-blend-arw">
		</g>
		<g id="round-extand">
		</g>
		<g id="round-close-arrow">
		</g>
		<g id="pluse-arrow">
		</g>
		<g id="crose-arrow">
		</g>
		<g id="corn-arrow">
		</g>
		<g id="side-arrow">
		</g>
		<g id="close-arrow-four">
		</g>
		<g id="stretch-arrow">
		</g>
		<g id="_x33__x2F_1-arrow">
		</g>
		<g id="_x32__x2F_1-arrow">
		</g>
		<g id="left-crose-rd">
		</g>
		<g id="left-crose-arrow">
		</g>
		<g id="left-top_arrows">
		</g>
		<g id="close-arrows">
		</g>
		<g id="extand-arrow">
		</g>
		<g id="parallel-arrows">
		</g>
		<g id="two-side_arrows">
		</g>
		<g id="right-arrows">
		</g>
		<g id="down-arrow-3">
		</g>
		<g id="top-arrow-3">
		</g>
		<g id="right-arrow-3">
		</g>
		<g id="left-arrow-3">
		</g>
		<g id="left-arrow-2">
			<g>
				<g>
					<path fill="#000000" d="M35,47c-0.256,0-0.512-0.098-0.707-0.293l-22-22c-0.391-0.391-0.391-1.023,0-1.414l22-22
						c0.391-0.391,1.023-0.391,1.414,0s0.391,1.023,0,1.414L14.414,24l21.293,21.293c0.391,0.391,0.391,1.023,0,1.414
						C35.512,46.902,35.256,47,35,47z"></path>
				</g>
			</g>
		</g>
		<g id="right-arrow-2">
		</g>
		<g id="down-arrow-2">
		</g>
		<g id="top-arrow-2">
		</g>
		<g id="down-arrow-1">
		</g>
		<g id="top-arrow-1">
		</g>
		<g id="rightarrow-1">
		</g>
		<g id="left-arrow-1">
		</g>
		<g id="down-play">
		</g>
		<g id="top-play">
		</g>
		<g id="right-play">
		</g>
		<g id="left-play">
		</g>
		<g id="down-arrow">
		</g>
		<g id="top-arrow">
		</g>
		<g id="right-arrow">
		</g>
		<g id="left-arrow">
		</g>
		<g id="channel">
		</g>
		<g id="stop_1_">
		</g>
		<g id="music-control">
		</g>
		<g id="adjust-lavel">
		</g>
		<g id="adjustsound">
		</g>
		<g id="graph-point">
		</g>
		<g id="symbol">
		</g>
		<g id="visual-graph">
		</g>
		<g id="visual">
		</g>
		<g id="adjust">
		</g>
		<g id="controal-4">
		</g>
		<g id="control-3">
		</g>
		<g id="control-2">
		</g>
		<g id="control_1_">
		</g>
		<g id="control">
		</g>
		<g id="volume-increase">
		</g>
		<g id="volume">
		</g>
		<g id="volume-close">
		</g>
		<g id="volume-minus">
		</g>
		<g id="volume-pluse">
		</g>
		<g id="block">
		</g>
		<g id="sound">
		</g>
		<g id="play-backward">
		</g>
		<g id="backward">
		</g>
		<g id="play">
		</g>
		<g id="hold">
		</g>
		<g id="stop">
		</g>
		<g id="pause">
		</g>
		<g id="forward">
		</g>
		<g id="play-forward">
		</g>
		<g id="top-bottom-arrow">
		</g>
		<g id="hook-right-arw">
		</g>
	</g>
</switch>
</svg>

</div>
<div class="title" style="margin-top:20px">Date &amp; Time</div>
</div>
<div id="error-presenter" style="display: none">
<a class="close" href="#">✕</a>
</div>

<div class="form-group hidden online_booking_form_provider_id"><input class="hidden form-control" type="hidden" value="59886" name="online_booking_form[provider_id]" id="online_booking_form_provider_id"></div>
<div class="form-group hidden online_booking_form_location_id"><input class="hidden form-control" type="hidden" value="" name="online_booking_form[location_id]" id="online_booking_form_location_id"></div>
<div class="form-group hidden online_booking_form_source"><input class="hidden form-control" type="hidden" value="online_button" name="online_booking_form[source]" id="online_booking_form_source"></div>
<input class="service-item-input-base" type="hidden" name="online_booking_form[service_pricing_level_ids][]">
<div class="service-item-input-list">
<input value="1456029" type="hidden" name="online_booking_form[service_pricing_level_ids][]">
</div>
<div class="form-group hidden online_booking_form_employee_id"><input class="hidden form-control" type="hidden" value="any" name="online_booking_form[employee_id]" id="online_booking_form_employee_id"></div>
<div class="form-group hidden online_booking_form_date"><input class="hidden js-date form-control" type="hidden" value="2018-02-05" name="online_booking_form[date]" id="online_booking_form_date"></div>
<div class="form-group hidden online_booking_form_time_start_in_seconds"><input class="hidden js-time-start-in-seconds form-control" type="hidden" value="" name="online_booking_form[time_start_in_seconds]" id="online_booking_form_time_start_in_seconds"></div>
<input class="employee-assignment-input-base" type="hidden" name="online_booking_form[employee_assignment][]">
<div class="employee-assignment-input-list"></div>
<input class="room-assignment-input-base" type="hidden" name="online_booking_form[room_assignment][]">
<div class="room-assignment-input-list"></div>
<div class="form-group hidden online_booking_form_booking_id"><input class="hidden form-control" type="hidden" value="" name="online_booking_form[booking_id]" id="online_booking_form_booking_id"></div>

<table class="" id="week-calendar">
<tbody><tr>
<td>
<a class="calendar-prev-week arrow disabled" href="#"><!--?xml version="1.0" encoding="utf-8"?-->
<!-- Generator: Adobe Illustrator 17.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->

<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 48 48" enable-background="new 0 0 48 48" xml:space="preserve">
<switch>
	<g>
		<g id="Layer_1">
		</g>
		<g id="right-rotate">
		</g>
		<g id="left-rotate">
		</g>
		<g id="share-down">
		</g>
		<g id="share-top">
		</g>
		<g id="share-both">
		</g>
		<g id="share-top-right">
		</g>
		<g id="share-top-left">
		</g>
		<g id="share-right-down">
		</g>
		<g id="share-left-down">
		</g>
		<g id="recycle-arw">
		</g>
		<g id="verticle-hidden-arw">
		</g>
		<g id="horizontal-arw">
		</g>
		<g id="verticle-arw">
		</g>
		<g id="connection-arw-r">
		</g>
		<g id="connection-arw-l">
		</g>
		<g id="connection-arw">
		</g>
		<g id="hook-left-arw">
		</g>
		<g id="clock-arw">
		</g>
		<g id="anti-clock-arw">
		</g>
		<g id="infinity">
		</g>
		<g id="sing-sang-arw">
		</g>
		<g id="anti-reload">
		</g>
		<g id="reload">
		</g>
		<g id="double-arrow">
		</g>
		<g id="single-circle-arw">
		</g>
		<g id="circle-arw">
		</g>
		<g id="two-side-bend-arw">
		</g>
		<g id="left-blend-arw">
		</g>
		<g id="right-blend-arw">
		</g>
		<g id="round-extand">
		</g>
		<g id="round-close-arrow">
		</g>
		<g id="pluse-arrow">
		</g>
		<g id="crose-arrow">
		</g>
		<g id="corn-arrow">
		</g>
		<g id="side-arrow">
		</g>
		<g id="close-arrow-four">
		</g>
		<g id="stretch-arrow">
		</g>
		<g id="_x33__x2F_1-arrow">
		</g>
		<g id="_x32__x2F_1-arrow">
		</g>
		<g id="left-crose-rd">
		</g>
		<g id="left-crose-arrow">
		</g>
		<g id="left-top_arrows">
		</g>
		<g id="close-arrows">
		</g>
		<g id="extand-arrow">
		</g>
		<g id="parallel-arrows">
		</g>
		<g id="two-side_arrows">
		</g>
		<g id="right-arrows">
		</g>
		<g id="down-arrow-3">
		</g>
		<g id="top-arrow-3">
		</g>
		<g id="right-arrow-3">
		</g>
		<g id="left-arrow-3">
		</g>
		<g id="left-arrow-2">
			<g>
				<g>
					<path fill="#000000" d="M35,47c-0.256,0-0.512-0.098-0.707-0.293l-22-22c-0.391-0.391-0.391-1.023,0-1.414l22-22
						c0.391-0.391,1.023-0.391,1.414,0s0.391,1.023,0,1.414L14.414,24l21.293,21.293c0.391,0.391,0.391,1.023,0,1.414
						C35.512,46.902,35.256,47,35,47z"></path>
				</g>
			</g>
		</g>
		<g id="right-arrow-2">
		</g>
		<g id="down-arrow-2">
		</g>
		<g id="top-arrow-2">
		</g>
		<g id="down-arrow-1">
		</g>
		<g id="top-arrow-1">
		</g>
		<g id="rightarrow-1">
		</g>
		<g id="left-arrow-1">
		</g>
		<g id="down-play">
		</g>
		<g id="top-play">
		</g>
		<g id="right-play">
		</g>
		<g id="left-play">
		</g>
		<g id="down-arrow">
		</g>
		<g id="top-arrow">
		</g>
		<g id="right-arrow">
		</g>
		<g id="left-arrow">
		</g>
		<g id="channel">
		</g>
		<g id="stop_1_">
		</g>
		<g id="music-control">
		</g>
		<g id="adjust-lavel">
		</g>
		<g id="adjustsound">
		</g>
		<g id="graph-point">
		</g>
		<g id="symbol">
		</g>
		<g id="visual-graph">
		</g>
		<g id="visual">
		</g>
		<g id="adjust">
		</g>
		<g id="controal-4">
		</g>
		<g id="control-3">
		</g>
		<g id="control-2">
		</g>
		<g id="control_1_">
		</g>
		<g id="control">
		</g>
		<g id="volume-increase">
		</g>
		<g id="volume">
		</g>
		<g id="volume-close">
		</g>
		<g id="volume-minus">
		</g>
		<g id="volume-pluse">
		</g>
		<g id="block">
		</g>
		<g id="sound">
		</g>
		<g id="play-backward">
		</g>
		<g id="backward">
		</g>
		<g id="play">
		</g>
		<g id="hold">
		</g>
		<g id="stop">
		</g>
		<g id="pause">
		</g>
		<g id="forward">
		</g>
		<g id="play-forward">
		</g>
		<g id="top-bottom-arrow">
		</g>
		<g id="hook-right-arw">
		</g>
	</g>
</switch>
</svg>

</a></td>
<td>
<a class="calendar-day calendar-day-0 selected" href="#">
<div class="week-day-name">Mon</div>
<div class="day-number">5</div>
<div class="month-name">Feb</div>
</a>
</td>
<td>
<a class="calendar-day calendar-day-1" href="#">
<div class="week-day-name">Tue</div>
<div class="day-number">6</div>
<div class="month-name">Feb</div>
</a>
</td>
<td>
<a class="calendar-day calendar-day-2" href="#">
<div class="week-day-name">Wed</div>
<div class="day-number">7</div>
<div class="month-name">Feb</div>
</a>
</td>
<td>
<a class="calendar-day calendar-day-3" href="#">
<div class="week-day-name">Thu</div>
<div class="day-number">8</div>
<div class="month-name">Feb</div>
</a>
</td>
<td>
<a class="calendar-day calendar-day-4" href="#">
<div class="week-day-name">Fri</div>
<div class="day-number">9</div>
<div class="month-name">Feb</div>
</a>
</td>
<td>
<a class="calendar-day calendar-day-5" href="#">
<div class="week-day-name">Sat</div>
<div class="day-number">10</div>
<div class="month-name">Feb</div>
</a>
</td>
<td>
<a class="calendar-day calendar-day-6" href="#">
<div class="week-day-name">Sun</div>
<div class="day-number">11</div>
<div class="month-name">Feb</div>
</a>
</td>
<td>
<a class="calendar-next-week arrow" href="#"><!--?xml version="1.0" encoding="utf-8"?-->
<!-- Generator: Adobe Illustrator 17.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->

<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 48 48" enable-background="new 0 0 48 48" xml:space="preserve">
<switch>
	<g>
		<g id="Layer_1">
		</g>
		<g id="right-rotate">
		</g>
		<g id="left-rotate">
		</g>
		<g id="share-down">
		</g>
		<g id="share-top">
		</g>
		<g id="share-both">
		</g>
		<g id="share-top-right">
		</g>
		<g id="share-top-left">
		</g>
		<g id="share-right-down">
		</g>
		<g id="share-left-down">
		</g>
		<g id="recycle-arw">
		</g>
		<g id="verticle-hidden-arw">
		</g>
		<g id="horizontal-arw">
		</g>
		<g id="verticle-arw">
		</g>
		<g id="connection-arw-r">
		</g>
		<g id="connection-arw-l">
		</g>
		<g id="connection-arw">
		</g>
		<g id="hook-left-arw">
		</g>
		<g id="clock-arw">
		</g>
		<g id="anti-clock-arw">
		</g>
		<g id="infinity">
		</g>
		<g id="sing-sang-arw">
		</g>
		<g id="anti-reload">
		</g>
		<g id="reload">
		</g>
		<g id="double-arrow">
		</g>
		<g id="single-circle-arw">
		</g>
		<g id="circle-arw">
		</g>
		<g id="two-side-bend-arw">
		</g>
		<g id="left-blend-arw">
		</g>
		<g id="right-blend-arw">
		</g>
		<g id="round-extand">
		</g>
		<g id="round-close-arrow">
		</g>
		<g id="pluse-arrow">
		</g>
		<g id="crose-arrow">
		</g>
		<g id="corn-arrow">
		</g>
		<g id="side-arrow">
		</g>
		<g id="close-arrow-four">
		</g>
		<g id="stretch-arrow">
		</g>
		<g id="_x33__x2F_1-arrow">
		</g>
		<g id="_x32__x2F_1-arrow">
		</g>
		<g id="left-crose-rd">
		</g>
		<g id="left-crose-arrow">
		</g>
		<g id="left-top_arrows">
		</g>
		<g id="close-arrows">
		</g>
		<g id="extand-arrow">
		</g>
		<g id="parallel-arrows">
		</g>
		<g id="two-side_arrows">
		</g>
		<g id="right-arrows">
		</g>
		<g id="down-arrow-3">
		</g>
		<g id="top-arrow-3">
		</g>
		<g id="right-arrow-3">
		</g>
		<g id="left-arrow-3">
		</g>
		<g id="left-arrow-2">
		</g>
		<g id="right-arrow-2">
			<g>
				<g>
					<path fill="#000000" d="M13,47c-0.256,0-0.512-0.098-0.707-0.293c-0.391-0.391-0.391-1.023,0-1.414L33.586,24L12.293,2.707
						c-0.391-0.391-0.391-1.023,0-1.414s1.023-0.391,1.414,0l22,22c0.391,0.391,0.391,1.023,0,1.414l-22,22
						C13.512,46.902,13.256,47,13,47z"></path>
				</g>
			</g>
		</g>
		<g id="down-arrow-2">
		</g>
		<g id="top-arrow-2">
		</g>
		<g id="down-arrow-1">
		</g>
		<g id="top-arrow-1">
		</g>
		<g id="rightarrow-1">
		</g>
		<g id="left-arrow-1">
		</g>
		<g id="down-play">
		</g>
		<g id="top-play">
		</g>
		<g id="right-play">
		</g>
		<g id="left-play">
		</g>
		<g id="down-arrow">
		</g>
		<g id="top-arrow">
		</g>
		<g id="right-arrow">
		</g>
		<g id="left-arrow">
		</g>
		<g id="channel">
		</g>
		<g id="stop_1_">
		</g>
		<g id="music-control">
		</g>
		<g id="adjust-lavel">
		</g>
		<g id="adjustsound">
		</g>
		<g id="graph-point">
		</g>
		<g id="symbol">
		</g>
		<g id="visual-graph">
		</g>
		<g id="visual">
		</g>
		<g id="adjust">
		</g>
		<g id="controal-4">
		</g>
		<g id="control-3">
		</g>
		<g id="control-2">
		</g>
		<g id="control_1_">
		</g>
		<g id="control">
		</g>
		<g id="volume-increase">
		</g>
		<g id="volume">
		</g>
		<g id="volume-close">
		</g>
		<g id="volume-minus">
		</g>
		<g id="volume-pluse">
		</g>
		<g id="block">
		</g>
		<g id="sound">
		</g>
		<g id="play-backward">
		</g>
		<g id="backward">
		</g>
		<g id="play">
		</g>
		<g id="hold">
		</g>
		<g id="stop">
		</g>
		<g id="pause">
		</g>
		<g id="forward">
		</g>
		<g id="play-forward">
		</g>
		<g id="top-bottom-arrow">
		</g>
		<g id="hook-right-arw">
		</g>
	</g>
</switch>
</svg>
</a></td>
</tr>
</tbody></table>
<div class="time-slots-available initially-hidden" style="display: none;">
<div class="group-name">
<div class="default" style="display: none;">Available Times</div>
<div class="other-staff initially-hidden" style="display: block;">Other Staff Availability</div>
</div>
<div class="group time-group"></div>
</div>
<div class="time-slots-status time-slots-unavailable initially-hidden" style="display: block;">
<!--?xml version="1.0" encoding="utf-8"?-->
<!-- Generator: Adobe Illustrator 17.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->

<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 48 48" enable-background="new 0 0 48 48" xml:space="preserve">
<g id="Layer_1">
</g>
<g id="medium-box">
</g>
<g id="minuse">
</g>
<g id="timer">
</g>
<g id="drawer-2">
</g>
<g id="trash-box">
</g>
<g id="book-label">
</g>
<g id="folder-label">
</g>
<g id="page-back">
</g>
<g id="close-page_1_">
</g>
<g id="pages">
</g>
<g id="list">
</g>
<g id="wave">
</g>
<g id="close-page">
</g>
<g id="add-page">
</g>
<g id="code">
</g>
<g id="shift-mode">
</g>
<g id="bookmarks_1_">
</g>
<g id="bookmarks">
</g>
<g id="open-pages">
</g>
<g id="note">
</g>
<g id="locater">
</g>
<g id="navigater">
</g>
<g id="alarm">
</g>
<g id="clock">
</g>
<g id="time-3">
	<path fill="#000000" d="M24,46.5C11.6,46.5,1.5,36.4,1.5,24S11.6,1.5,24,1.5S46.5,11.6,46.5,24S36.4,46.5,24,46.5z M24,3.5
		C12.7,3.5,3.5,12.7,3.5,24S12.7,44.5,24,44.5S44.5,35.3,44.5,24S35.3,3.5,24,3.5z"></path>
	<path fill="#000000" d="M24,7c-0.3,0-0.5-0.1-0.7-0.3C23.1,6.5,23,6.3,23,6c0-0.3,0.1-0.5,0.3-0.7c0.4-0.4,1-0.4,1.4,0
		C24.9,5.5,25,5.7,25,6c0,0.3-0.1,0.5-0.3,0.7C24.5,6.9,24.3,7,24,7z"></path>
	<path fill="#000000" d="M24,43c-0.3,0-0.5-0.1-0.7-0.3C23.1,42.5,23,42.3,23,42s0.1-0.5,0.3-0.7c0.4-0.4,1-0.4,1.4,0
		c0.2,0.2,0.3,0.4,0.3,0.7c0,0.3-0.1,0.5-0.3,0.7C24.5,42.9,24.3,43,24,43z"></path>
	<path fill="#000000" d="M42,25c-0.3,0-0.5-0.1-0.7-0.3C41.1,24.5,41,24.3,41,24s0.1-0.5,0.3-0.7c0.4-0.4,1-0.4,1.4,0
		c0.2,0.2,0.3,0.5,0.3,0.7s-0.1,0.5-0.3,0.7C42.5,24.9,42.3,25,42,25z"></path>
	<path fill="#000000" d="M6,25c-0.3,0-0.5-0.1-0.7-0.3C5.1,24.5,5,24.3,5,24s0.1-0.5,0.3-0.7c0.4-0.4,1-0.4,1.4,0
		C6.9,23.5,7,23.7,7,24s-0.1,0.5-0.3,0.7C6.5,24.9,6.3,25,6,25z"></path>
	<path fill="#000000" d="M36.7,12.3c-0.3,0-0.5-0.1-0.7-0.3c-0.2-0.2-0.3-0.4-0.3-0.7c0-0.3,0.1-0.5,0.3-0.7c0.4-0.4,1-0.4,1.4,0
		c0.2,0.2,0.3,0.5,0.3,0.7c0,0.3-0.1,0.5-0.3,0.7C37.3,12.2,37,12.3,36.7,12.3z"></path>
	<path fill="#000000" d="M11.3,37.7c-0.3,0-0.5-0.1-0.7-0.3c-0.2-0.2-0.3-0.4-0.3-0.7c0-0.3,0.1-0.5,0.3-0.7c0.4-0.4,1-0.4,1.4,0
		c0.2,0.2,0.3,0.4,0.3,0.7c0,0.3-0.1,0.5-0.3,0.7C11.8,37.6,11.5,37.7,11.3,37.7z"></path>
	<path fill="#000000" d="M36.7,37.7c-0.3,0-0.5-0.1-0.7-0.3c-0.2-0.2-0.3-0.4-0.3-0.7c0-0.3,0.1-0.5,0.3-0.7c0.4-0.4,1-0.4,1.4,0
		c0.2,0.2,0.3,0.5,0.3,0.7c0,0.3-0.1,0.5-0.3,0.7C37.3,37.6,37,37.7,36.7,37.7z"></path>
	<path fill="#000000" d="M11.3,12.3c-0.3,0-0.5-0.1-0.7-0.3c-0.2-0.2-0.3-0.4-0.3-0.7c0-0.3,0.1-0.5,0.3-0.7c0.4-0.4,1-0.4,1.4,0
		c0.2,0.2,0.3,0.5,0.3,0.7c0,0.3-0.1,0.5-0.3,0.7C11.8,12.2,11.5,12.3,11.3,12.3z"></path>
	<path fill="#000000" d="M34,35c-0.3,0-0.5-0.1-0.7-0.3l-10-10C23.1,24.5,23,24.3,23,24V14c0-0.6,0.4-1,1-1s1,0.4,1,1v9.6l9.7,9.7
		c0.4,0.4,0.4,1,0,1.4C34.5,34.9,34.3,35,34,35z"></path>
</g>
<g id="time-1">
</g>
<g id="time">
</g>
<g id="downloads">
</g>
<g id="uploads">
</g>
<g id="drawer-1">
</g>
<g id="mail_drawer">
</g>
<g id="drawer">
</g>
<g id="mail_1_">
</g>
<g id="mail-open">
</g>
<g id="open">
</g>
<g id="card">
</g>
<g id="mails">
</g>
<g id="mail">
</g>
<g id="drag-l-t">
</g>
<g id="comment">
</g>
<g id="folder">
</g>
<g id="trash">
</g>
<g id="report-flag">
</g>
<g id="setting-roll">
</g>
<g id="spects">
</g>
<g id="search_1_">
</g>
<g id="game-2">
</g>
<g id="game">
</g>
<g id="unloack">
</g>
<g id="loack">
</g>
<g id="settings-ui">
</g>
<g id="abacuse">
</g>
<g id="browser-check-box">
</g>
<g id="browser-reload">
</g>
<g id="browser-check">
</g>
<g id="browser-close">
</g>
<g id="browser-inus">
</g>
<g id="browser-add">
</g>
<g id="flowtting">
</g>
<g id="drag">
</g>
<g id="popup">
</g>
<g id="latter">
</g>
<g id="details">
</g>
<g id="blocks">
</g>
<g id="locate">
</g>
<g id="parabolla">
</g>
<g id="check-box">
</g>
<g id="slide-nav">
</g>
<g id="share">
</g>
<g id="profile">
</g>
<g id="settings">
</g>
<g id="expand">
</g>
<g id="image">
</g>
<g id="pause">
</g>
<g id="player">
</g>
<g id="imager">
</g>
<g id="slider">
</g>
<g id="slide-count">
</g>
<g id="progress-bar">
</g>
<g id="graph">
</g>
<g id="statistics">
</g>
<g id="cloud-reload">
</g>
<g id="cloud-down">
</g>
<g id="cloud-up">
</g>
<g id="cloud">
</g>
<g id="masonary">
</g>
<g id="column">
</g>
<g id="grid-block">
</g>
<g id="horizontal">
</g>
<g id="_x35_-column">
</g>
<g id="_x31_-column">
</g>
<g id="_x33_-column">
</g>
<g id="sidebar_1_">
</g>
<g id="favorite">
</g>
<g id="load">
</g>
<g id="search-list">
</g>
<g id="search">
</g>
<g id="browser_1_">
</g>
<g id="change-mode">
</g>
<g id="tick">
</g>
</svg>

<p class="lead">There's no availability on this date, pick another one instead.</p>
</div>
<div class="time-slots-status time-slots-unavailable-for-selected-staff initially-hidden" style="display: none;">
<div class="fit-width">
<!--?xml version="1.0" encoding="utf-8"?-->
<!-- Generator: Adobe Illustrator 17.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->

<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 48 48" enable-background="new 0 0 48 48" xml:space="preserve">
<g id="date">
	<path fill="#626262" d="M22.783,29.779c-5.517,0-9.368-6.63-10.288-9.337c-0.05-0.031-0.104-0.064-0.157-0.097
		c-0.36-0.224-0.599-0.372-0.755-0.65c-1.324-2.344-1.675-4.221-1.04-5.579c0.304-0.65,0.764-1.043,1.167-1.277
		c-0.001-1.014,0.073-2.952,0.571-4.833c0.021-0.075,1.996-7.04,10.502-7.04s10.481,6.965,10.501,7.036
		c0.499,1.885,0.573,3.824,0.572,4.838c0.403,0.234,0.863,0.626,1.166,1.276c0.635,1.357,0.284,3.235-1.041,5.582
		c-0.155,0.276-0.393,0.423-0.753,0.646c-0.053,0.033-0.107,0.066-0.158,0.098C32.146,23.154,28.293,29.779,22.783,29.779z
		 M13.232,18.547c0.049,0.031,0.104,0.064,0.161,0.1c0.464,0.288,0.799,0.497,0.927,0.936c0.5,1.738,3.885,8.197,8.463,8.197
		c4.574,0,7.962-6.46,8.462-8.195c0.125-0.439,0.462-0.648,0.928-0.938c0.057-0.035,0.111-0.068,0.159-0.099
		c1.227-2.233,1.033-3.23,0.89-3.56c-0.175-0.401-0.543-0.499-0.584-0.509c-0.47-0.112-0.82-0.551-0.794-1.033
		c0.001-0.025,0.129-2.582-0.492-4.927c-0.061-0.218-1.631-5.552-8.568-5.552c-6.991,0-8.555,5.5-8.569,5.556
		c-0.623,2.352-0.492,4.896-0.491,4.922c0.028,0.502-0.322,0.947-0.817,1.038c-0.019,0.005-0.387,0.104-0.562,0.505
		C12.2,15.317,12.007,16.314,13.232,18.547z"></path>
	<path fill="#626262" d="M29.997,30.094c-0.155,0-0.313-0.036-0.46-0.112c-2.028-1.053-2.632-2.08-2.732-2.275
		c-0.252-0.491-0.059-1.094,0.433-1.346c0.486-0.249,1.075-0.064,1.333,0.407c0.031,0.049,0.466,0.701,1.889,1.439
		c0.49,0.254,0.681,0.858,0.427,1.348C30.708,29.897,30.358,30.094,29.997,30.094z"></path>
	<path fill="#626262" d="M23.305,47.037c-11.504,0-22.041-1.914-22.154-1.935c-0.492-0.09-0.842-0.531-0.818-1.031
		c0.476-9.972,6.688-13.069,11.319-14.53c3.609-1.139,5.498-2.983,5.517-3.002c0.393-0.388,1.025-0.386,1.414,0.006
		c0.389,0.393,0.387,1.025-0.006,1.415c-0.091,0.089-2.257,2.205-6.323,3.488c-4.513,1.424-9.175,3.956-9.864,11.837
		C5.384,43.776,15.595,45.288,25.972,45c0.561-0.015,1.013,0.419,1.028,0.972c0.015,0.552-0.42,1.012-0.972,1.027
		C25.117,47.025,24.208,47.037,23.305,47.037z"></path>
	<path fill="#626262" d="M44,47H32c-1.103,0-2-0.897-2-2V34c0-1.103,0.897-2,2-2h12c1.103,0,2,0.897,2,2v11
		C46,46.103,45.103,47,44,47z M32,34v11h12.001L44,34H32z"></path>
	<path fill="#626262" d="M44,39H32c-0.553,0-1-0.448-1-1s0.447-1,1-1h12c0.553,0,1,0.448,1,1S44.553,39,44,39z"></path>
	<path fill="#626262" d="M35,36c-0.553,0-1-0.448-1-1v-4c0-0.552,0.447-1,1-1s1,0.448,1,1v4C36,35.552,35.553,36,35,36z"></path>
	<path fill="#626262" d="M41,36c-0.553,0-1-0.448-1-1v-4c0-0.552,0.447-1,1-1s1,0.448,1,1v4C42,35.552,41.553,36,41,36z"></path>
</g>
</svg>

<p class="lead">Tiffany is not available on this day</p>
<div class="actions">
<a class="show-other-staff button" href="">Show times with other staff</a>
<a class="go-to-next-day button" href="">Try the next day</a>
</div>
</div>
</div>
<div class="time-slots-status time-slots-fetching initially-hidden" style="display: none;">
<img src="//d3ith3umqn03s3.cloudfront.net/assets/pages/progress/progress-circle-complete-f5a6df30c3c3ffa7d4523cae154750e518f6da1c49d113be21f56ac60d050de6.svg" alt="Progress circle complete">
</div>
<div class="time-slots-status time-slots-fetching-error initially-hidden" style="display: none;">
<p>Failed to connect with the server.</p>
<a class="button fetch-day-again" href="#">Try again</a>
</div>
<input type="submit" name="commit" value="Next" class="hide">
</form>
</div>

							
					</div>
				</div>

			<!-- Footer -->
				<footer id="footer" class="container">
					<div class="row 200%">
						<div class="12u">

							<!-- About -->
								<section>
									
								</section>

						</div>
					</div>
					<div class="row 200%">
						<div class="12u">

							<!-- Contact -->
								<section>
									<h2 class="major"><span>Get in touch</span></h2>
									<ul class="contact">
										<li><a class="icon fa-facebook" href="https://www.facebook.com/wecaremassage"><span class="label">Facebook</span></a></li>
										<li><a class="icon fa-twitter" href="#"><span class="label">Twitter</span></a></li>
										<li><a class="icon fa-instagram" href="#"><span class="label">Instagram</span></a></li>
										<li><a class="icon fa-dribbble" href="#"><span class="label">Dribbble</span></a></li>
										<li><a class="icon fa-google-plus" href="#"><span class="label">Google+</span></a></li>
									</ul>
								</section>

						</div>
					</div>

					<!-- Copyright -->
						<div id="copyright">
							<ul class="menu">
								<li>&copy; WeCare Massage. All rights reserved</li>
							</ul>
						</div>

				</footer>

	</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/skel-viewport.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>